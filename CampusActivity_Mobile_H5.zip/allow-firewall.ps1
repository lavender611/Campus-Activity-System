﻿$ErrorActionPreference = 'Stop'

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
  Write-Host '需要管理员权限：请右键“允许手机访问.bat”，选择“以管理员身份运行”。' -ForegroundColor Red
  Read-Host '按回车退出'
  exit 1
}

Write-Host '正在为“专用网络”放行 TCP 5173 端口…' -ForegroundColor Yellow
try {
  New-NetFirewallRule -DisplayName 'CampusActivity-Mobile-5173' -Direction Inbound -Protocol TCP -LocalPort 5173 -Action Allow -Profile Private -Force | Out-Null
  Write-Host '已放行，手机现在可以访问本机 5173 端口。' -ForegroundColor Green
} catch {
  Write-Host ('放行失败：' + $_.Exception.Message) -ForegroundColor Red
}
Read-Host '按回车退出'
